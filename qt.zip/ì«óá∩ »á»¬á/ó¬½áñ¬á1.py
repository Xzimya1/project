from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form2(object):
    def setupUi(self, Form2):
        Form2.setObjectName("Form2")
        Form2.resize(400, 300)
        Form2.setMaximumSize(QtCore.QSize(400, 300))
        self.label = QtWidgets.QLabel(Form2)
        self.label.setGeometry(QtCore.QRect(-10, -20, 421, 341))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("квадрат.png"))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Form2)
        self.label_2.setGeometry(QtCore.QRect(0, 190, 131, 111))
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap("Без и132мени-1.png"))
        self.label_2.setObjectName("label_2")
        self.lineEdit = QtWidgets.QLineEdit(Form2)
        self.lineEdit.setGeometry(QtCore.QRect(20, 50, 361, 31))
        self.lineEdit.setStyleSheet("\n"
"background-color: rgb(222, 222, 222);")
        self.lineEdit.setObjectName("lineEdit")
        self.label_3 = QtWidgets.QLabel(Form2)
        self.label_3.setGeometry(QtCore.QRect(20, 10, 81, 41))
        font = QtGui.QFont()
        font.setFamily("Arial Black")
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("color: rgb(180, 180, 180);")
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(Form2)
        self.label_4.setGeometry(QtCore.QRect(20, 80, 251, 41))
        font = QtGui.QFont()
        font.setFamily("Arial Black")
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet("color: rgb(180, 180, 180);")
        self.label_4.setObjectName("label_4")
        self.lineEdit_2 = QtWidgets.QLineEdit(Form2)
        self.lineEdit_2.setGeometry(QtCore.QRect(20, 120, 361, 31))
        self.lineEdit_2.setStyleSheet("\n"
"background-color: rgb(222, 222, 222);")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.pushButton = QtWidgets.QPushButton(Form2)
        self.pushButton.setGeometry(QtCore.QRect(310, 270, 75, 23))
        self.pushButton.setObjectName("pushButton")

        self.retranslateUi(Form2)
        QtCore.QMetaObject.connectSlotsByName(Form2)

    def retranslateUi(self, Form2):
        _translate = QtCore.QCoreApplication.translate
        Form2.setWindowTitle(_translate("Form2", "Form"))
        self.label_3.setText(_translate("Form2", "ФИО"))
        self.label_4.setText(_translate("Form2", "Класс обучения"))
        self.pushButton.setText(_translate("Form2", "OK"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form2 = QtWidgets.QWidget()
    ui = Ui_Form2()
    ui.setupUi(Form2)
    Form2.show()
    sys.exit(app.exec_())
